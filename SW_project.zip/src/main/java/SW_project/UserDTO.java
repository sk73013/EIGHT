package SW_project;

public class UserDTO {
	private String user_ID;
	private String user_PW;
	private String user_name;

	public UserDTO(String user_ID, String user_PW, String user_name) {
		super();
		this.user_ID = user_ID;
		this.user_PW = user_PW;
		this.user_name = user_name;
	}
	
	public UserDTO() {
		
	}

	public String getUser_ID() {
		return user_ID;
	}

	public void setUser_ID(String user_ID) {
		this.user_ID = user_ID;
	}

	public String getUser_PW() {
		return user_PW;
	}

	public void setUser_PW(String user_PW) {
		this.user_PW = user_PW;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	
	
}
