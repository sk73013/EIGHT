package SW_project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class UserDAO {
	private String jdbcDriver = "jdbc:mariadb://localhost:3307/SW_project";
	private String dbUser = "root";
	private String dbPass = "150529";
	
	public UserDAO() {
		
	}
	
	
	public ArrayList<UserDTO> UserSelect() {
		ArrayList<UserDTO> dtos = new ArrayList<UserDTO>();
		
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		try {
			con = DriverManager.getConnection(jdbcDriver, dbUser, dbPass);
			stmt = con.createStatement();
			rs = stmt.executeQuery("select * from user");
			
			while (rs.next()) {
				String user_ID = rs.getString("user_ID");
				String user_PW = rs.getString("user_PW");
				String user_name = rs.getString("user_name");
				
				UserDTO dto = new UserDTO(user_ID, user_PW, user_name);
				dtos.add(dto);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(stmt != null) stmt.close();
				if(con != null) con.close();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		return dtos;
	}
	

	public UserDTO UserSelectOne(String ID) {
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		UserDTO dto = new UserDTO();
		
		try {
			con = DriverManager.getConnection(jdbcDriver, dbUser, dbPass);
			stmt = con.createStatement();
			rs = stmt.executeQuery("select * from user where user_ID = " + ID);
			
			while (rs.next()) {
				String user_ID = rs.getString("user_ID");
				String user_PW = rs.getString("user_PW");
				String user_name = rs.getString("user_name");
				
				dto = new UserDTO(user_ID, user_PW, user_name);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(stmt != null) stmt.close();
				if(con != null) con.close();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		return dto;
	}
	

	public int InsertUser(UserDTO dto) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String query = "insert into user values (?, ?, ?)";
		int result = 0;
	
		try {
			con = DriverManager.getConnection(jdbcDriver, dbUser, dbPass);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, dto.getUser_ID());
			pstmt.setString(2, dto.getUser_PW());
			pstmt.setString(3, dto.getUser_name());
			
			result = pstmt.executeUpdate();
			pstmt.close();
			con.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	
	public int DeleteUser(String user_ID) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = "delete from user where user_ID = ?";
		int result = 0;
		try {
			con = DriverManager.getConnection(jdbcDriver, dbUser, dbPass);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, user_ID);
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(con != null) con.close();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		return result;
	}
	

	public int UpdateUser(UserDTO dto) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = "update user set user_PW = ?, user_name = ? where user_ID = ?";
		int result = 0;
		try {
			con = DriverManager.getConnection(jdbcDriver, dbUser, dbPass);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, dto.getUser_PW());
			pstmt.setString(2, dto.getUser_name());
			pstmt.setString(3, dto.getUser_ID());
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(con != null) con.close();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		return result;
	}


public int UserCheck(String id, String pw) 
{
	Connection con = null;
	Statement stmt = null;
	ResultSet rs = null;
	String query = "select * from user where user_ID =\""+id+"\"";
	int x = -1;
	
	try {
		con = DriverManager.getConnection(jdbcDriver, dbUser, dbPass);
		stmt = con.createStatement();
		rs = stmt.executeQuery(query);

        if (rs.next()) 
        {
            String dbPW = rs.getString("user_PW"); 

            if (dbPW.equals(pw)) 
                x = 1; 
            else                  
                x = 0; 
            
        } else {
            x = -1; 
        }

        return x;

    } catch (Exception sqle) {
        throw new RuntimeException(sqle.getMessage());
    } finally {
        try{
            if ( stmt != null ){ stmt.close(); stmt=null; }
            if ( con != null ){ con.close(); con=null;    }
        }catch(Exception e){
            throw new RuntimeException(e.getMessage());
        }
    }
}

public ArrayList<UserDTO> UserView(String id) {
	ArrayList<UserDTO> dtos = new ArrayList<UserDTO>();
	
	Connection con = null;
	Statement stmt = null;
	ResultSet rs = null;
	
	
	try {
		con = DriverManager.getConnection(jdbcDriver, dbUser, dbPass);
		stmt = con.createStatement();
		rs = stmt.executeQuery( "select * from user where user_ID =\""+id+"\"");
		
		while (rs.next()) {
			
			String user_ID = rs.getString("user_ID");
			String user_PW = rs.getString("user_PW");
			String user_name = rs.getString("user_name");

			
			UserDTO dto = new UserDTO(user_ID, user_PW, user_name);
			dtos.add(dto);
		}
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		try {
			if(rs != null) rs.close();
			if(stmt != null) stmt.close();
			if(con != null) con.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	return dtos;
	
}


}
